type tree = TreeNode of string * tree list;;
